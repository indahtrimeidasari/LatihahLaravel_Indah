<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\c_mahasiswa;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
});

Route::get('/contact', function () {
    return view('v_contact');
});

Route::get('/about', function () {
    return 'Halaman About';
});

Route::get('/kali', function () {
    return 9*9;
});

Route :: view('/contact','v_contact');

Route :: view('/contact','v_contact',[
    'name' => 'Indah Tri Meidasari',
    'email' => 'indahtrimeidasari@gmail.com']);

Route::get('/contact', function (){
    return view('v_contact',['name' => 'Indah Tri meidasari','email' => 'indahtrimeidasari@gmail.com']);
});

Route :: view('/admin', 'admin/v_admin');
Route :: view('/admin', 'admin.v_admin');

Route::get('/mahasiswa/', function ($nama_mahasiswa='Indah') {
    return view('v_mahasiswa',['nama_mahasiswa'=>$nama_mahasiswa]);
});

Route::view('/about','v_about',[
    'nama' => 'Mahasiswa A',
    'alamat' => 'Cibogo, Subang'
]);

Route::view('/dosen', 'v_dosen');
Route::view('/mahasiswa','v_mahasiswa');
Route::view('/about', 'v_about');
Route::view('/contact', 'v_contact');

Route::view('/login', 'v_login');
Route::view('/barang', 'v_barang');
*/
Route::get('/', function () {
    return view('v_index');
});

Route::view('/admin', 'admin/v_dashboard');

Route::get('/', [c_login::class, 'index']);
Route::get('/home', [c_home::class, 'index']);
Route::get('dosen', [c_dosen::class, 'index']);
Route::get('/mahasiswa', [c_mahasiswa::class, 'index']);
