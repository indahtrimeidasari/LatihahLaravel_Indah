<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mahasiswa</title>
</head>
<body>
    <h1> Nama Mahasiswa : Indah Tri Meidasari </h1>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\latihan_laravel_indah\resources\views/mahasiswa.blade.php ENDPATH**/ ?>