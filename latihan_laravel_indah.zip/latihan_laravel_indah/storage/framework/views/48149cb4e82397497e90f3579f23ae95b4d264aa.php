<?php $__env->startSection('content'); ?>
    <h1>Hallo!!</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan_laravel_indah\resources\views/v_home.blade.php ENDPATH**/ ?>