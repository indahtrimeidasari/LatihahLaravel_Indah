@extends('layout.v_template')
@section('content')
    <h1>Hallo!!</h1>
@endsection
